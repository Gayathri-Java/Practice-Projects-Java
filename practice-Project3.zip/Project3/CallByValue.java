package Project3;

public class CallByValue {
	 private static void increment(int val) {
	        val++;
	        
	        System.out.println("Value = " + val);
	    }
	 
	    public static void main(String[] args) {
	        int num = 10;
	        System.out.println("Before calling: " + num);
	        increment(num);
	        System.out.println("After calling: " + num);
	    }

}
