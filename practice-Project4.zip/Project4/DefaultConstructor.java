package Project4;

        class Employee{
		int id;
		String name;
		String gender;

	void display() {
		System.out.println(id+" "+name+" "+gender);
		}
	}

	public class DefaultConstructor {

	public static void main(String[] args) {

		Employee emp1=new Employee();
		Employee emp2=new Employee();
		Employee emp3=new Employee();

		emp1.display();
		emp2.display();
		emp3.display();
		}
	}



