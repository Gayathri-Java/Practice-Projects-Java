package project2;


//public class
public class PublicAccess {
 // public variable
 public int legCount;

 // public method
 public void display() {
     System.out.println("Lion is an animal.");
     System.out.println("Lion have " + legCount + " legs.");
 }


//Main.java

 public static void main( String[] args ) {
     // accessing the public class
     PublicAccess animal = new PublicAccess();

     // accessing the public variable
     animal.legCount = 4;
     // accessing the public method
     animal.display();
 }
}

