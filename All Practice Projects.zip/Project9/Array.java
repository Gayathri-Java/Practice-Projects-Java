package Project9;

	public class Array {
	public static void main(String[] args) 
	{
	// Declare and initialize an array of five integer values.
	    int arr[] = {2, 4, 6, 8, 10};
	  
	// Display all five elements on the console.  
	   for (int i = 0; i < arr.length; i++)
	      System.out.println(arr[i] + " ");
	 }
	}

	