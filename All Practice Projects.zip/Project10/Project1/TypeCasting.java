package Project1;

public class TypeCasting {

	public static void main(String[] args) {
		//implicit conversion
		System.out.println("Implicit Type Casting");
		char a='B';
		System.out.println("Value of a: " +a);
		
		int b=a;
		System.out.println("Value of b: " +b);
		
		float f=a;
		System.out.println("Value of c: " +f);
		
		long l=a;
		System.out.println("Value of d: " +l);
		
		double d=a;
		System.out.println("Value of e: " +d);
		
				
		System.out.println("\n");
		
		
		
		//explicit conversion
		System.out.println("Explicit Type Casting");
		
		double y=50.6;
		int x=(int)y;
		System.out.println("Value of x: " +y);
		System.out.println("Value of y: " +x);
		
	}


	}


