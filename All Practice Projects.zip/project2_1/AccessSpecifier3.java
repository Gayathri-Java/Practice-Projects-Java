package project2_1;

import project2.Protected;

public class AccessSpecifier3 extends Protected {
	public static void main(String[] args) {
		AccessSpecifier3 obj = new AccessSpecifier3 ();   
	       obj.display();  
	}



}
