package Project4;

	class Student{
		int id;
		String name;
		String gender;

		Student(int i,String n,String g)
		{
		id=i;
		name=n;
		gender=g;
		}

		void display() {
		System.out.println(id+" "+name+" "+gender);
		}
	}
	public class ParameterizedConstructor {



	public static void main(String[] args) {

		Student std1=new Student(2,"Arjun","Male");
		Student std2=new Student(10,"Ammu","Female");
		std1.display();
		std2.display();
			}
	}


