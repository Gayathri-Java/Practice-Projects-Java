package project2;

public class Protected {
	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}


