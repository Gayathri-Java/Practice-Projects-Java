package Project5;


	import java.util.LinkedList;

	class List {
	  public static void main(String[] args){

	    // create linkedlist
	    LinkedList<String> animals = new LinkedList<>();

	    // Add elements to LinkedList
	    animals.add("Dog");
	    animals.add("Cat");
	    animals.add("Cow");
	    System.out.println("LinkedList: " + animals);
	  }
	}


