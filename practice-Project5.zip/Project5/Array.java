package Project5;

import java.util.ArrayList;
import java.util.Vector;


public class Array {
	public static void mian(String[] args) {
	
	//creating arraylist
		
			System.out.println("ArrayList");
			ArrayList<String> location=new ArrayList<String>();   
		      location.add("Bangalore");//
		      location.add("Delhi"); 
		      location.add("pune");
		      System.out.println(location);  
		
	//creating vector
    System.out.println("\n");
    System.out.println("Vector");
    Vector<Integer> vec = new Vector();
    vec.addElement(15); 
    vec.addElement(20); 
    System.out.println(vec);
	
	}
	
}

